<?php
$user=$_POST["user"];
$pass=$_POST["pass"];
$dir = "dlyz/$user";
if(is_dir($dir)){
 if($pass==@file_get_contents("user/$user.txt")){
 echo "登录成功 3秒后跳转";
if(!empty($_SERVER["HTTP_CLIENT_IP"])){
$cip = $_SERVER["HTTP_CLIENT_IP"];
}
elseif(!empty($_SERVER["HTTP_X_FORWARDED_FOR"])){
$cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
}
elseif(!empty($_SERVER["REMOTE_ADDR"])){
$cip = $_SERVER["REMOTE_ADDR"];
}
else{
$cip = "无法获取！";
}
// Your code here!
$f = fopen("ip/$cip.txt", "w");
fwrite($f, $cip);
 header("Refresh:3;url=dlcgzy.html");
}else{
 echo "密码错误";
}
}else{
echo "没注册 请前往注册(3秒后自动跳转)";
header("Refresh:3;url=zhuce.html");
}
?>