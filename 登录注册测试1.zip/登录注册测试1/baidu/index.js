function search (content){
    window.open("http://www.baidu.com/s?wd="+content);
}
function go(){
    var input=document.getElementById("search_textfield");
    if(input.value.trim() == ""){
        mdui.alert("Please input something and search again!","Alert");
    }
    else{
        search(input.value);
    }
}
