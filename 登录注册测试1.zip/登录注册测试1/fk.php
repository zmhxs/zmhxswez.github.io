<?php
$user=$_POST["user"];
$f = fopen("fk/$user.txt", "w");
fwrite($f, $user);
echo "反馈成功 3秒后自动跳转";
header("Refresh:3;url=dlcgzy.html");
?>