<?php
$user=$_POST["user"];
$pass=$_POST["pass"];
$f = fopen("user/$user.txt", "w");
fwrite($f, $pass);
$dir = "dlyz/$user";
if(is_dir($dir)){
echo "注册过了！";
}else{
if(mkdir($dir,0777,true)) echo '注册成功';
echo "请前往登录 2秒后自动跳转";
header("Refresh:2;url=dl.php");
}
?>